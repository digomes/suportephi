<?php
class DataTableAppController extends AppController {
	
}