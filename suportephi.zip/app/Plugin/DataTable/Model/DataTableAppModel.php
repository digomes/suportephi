<?php
class DataTableAppModel extends AppModel {
	
}