﻿/*
Copyright (c) 2003-2012, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/

CKEDITOR.editorConfig = function( config )
 {
    config.filebrowserBrowseUrl = '/suportephi/js/kcfinder/browse.php?type=files';
    config.filebrowserImageBrowseUrl = '/suportephi/js/kcfinder/browse.php?type=images';
    config.filebrowserFlashBrowseUrl = '/suportephi/js/kcfinder/browse.php?type=flash';
    config.filebrowserUploadUrl = '/suportephi/js/kcfinder/upload.php?type=files';
    config.filebrowserImageUploadUrl = '/suportephi/js/kcfinder/upload.php?type=images';
    config.filebrowserFlashUploadUrl = '/suportephi/js/kcfinder/upload.php?type=flash';
 };
